# MSX-JE 制御ガイド サンプルプログラム

「MSX-JE 制御ガイド」の各章に対応するサンプルプログラム集です。
すべて MSX-DOS2 用の .COM で、ZMA (Z80/R800 マクロアセンブラ) で
ビルドできます。各サンプルは MSX-JE の公開インターフェースだけを
使っています。

## ファイル一覧

| 章 | ファイル | 内容 | 出力ファイル |
|---|---|---|---|
| 第2章 | ch02/jedetect.asm | EXTBIO でモジュールテーブルを列挙し、各モジュールのケーパビリティ／スロット／エントリーと Inquiry の MIN/MIN2/MAX を表示。Invoke → Release の一巡も実行する | DETECT.TXT |
| 第3章 | ch03/hanhira.asm | ローマ字を打つと han_hira の変換結果をライブ表示する。未変換末尾は je_find_split の考え方 (入出力からの導出) で求め、分割位置を数値表示する | RESULT.TXT |
| 第3章 | ch03/henkan.asm | 変換 UI の一通り。読み入力 → henkan → 文節表示 → 文節の移動・伸縮 → 候補列挙 (ji_koho) → Enter 確定 | HENKAN.TXT |
| 第5章 | ch05/vtdemo.asm | VT の最小 FEP。Invoke → Clear → キー Dispatch → STB を最下行に描画 → 確定、という KID 方式の骨格 | VTRES.TXT |
| 第6章 | ch06/jemini.asm | 最小の DIC クライアント。本文 6.1 節の掲載コードそのもの。固定の読み「かんじ」を変換し、第 1 候補で確定して表示する | JEMINI.TXT |

各フォルダにはビルド済みの .COM も入っています。

## ビルド方法

各ソースのあるフォルダで、クロス版 zma を使います
(引数は入力ファイルと出力ファイルの 2 つです)。

```
zma jedetect.asm JEDETECT.COM
zma hanhira.asm  HANHIRA.COM
zma henkan.asm   HENKAN.COM
zma vtdemo.asm   VTDEMO.COM
zma jemini.asm   JEMINI.COM
```

成功すると "Success." と表示されます。失敗時は部分的な出力ファイルが
残ることがあるので、必ず "Success." を確認してください。

配布している .asm は Shift_JIS です。本文 (PDF) に掲載したコードと
内容は同一です。

## 動作環境

- MSX-DOS2 と MSX-JE が動作する環境 (MSX-JE 内蔵機、または
  MSX-Write II 等の JE カートリッジがある構成)
- 画面の日本語表示を読むには、漢字表示ができるコンソールが必要です
  (例: 起動時に CALL KANJI してから DOS に入る)。漢字表示でない
  コンソールでも動作はしますが、表示は文字化けして見えます。
  結果は各 .TXT ファイルにも書き出されるので、そちらでも確認できます。

## 操作

- jedetect / jemini: 起動するだけです。結果を表示して DOS に戻ります。
- hanhira: ローマ字キーで入力、BS/DEL で修正、Enter で RESULT.TXT に
  保存して終了、ESC で終了します。
- henkan: ローマ字で読みを入力し、SPACE で変換します。変換中は
  SPACE = 次候補、TAB = 前候補、←→ = 文節移動、
  Shift+←→ = 文節の伸縮、Enter = 確定、ESC = 取消です。
- vtdemo: 文字キーで入力し、SPACE で変換、Enter で確定します。
  ESC で終了します (変換中は取消)。確定結果は画面に残り、
  VTRES.TXT にも書き出されます。

## 注意

- 変換候補は JE の学習状態によって変わります。画面例 (本文の図) と
  違う候補が出ても異常ではありません。
- DIC バッファは本文 4.4 節の教えどおり、すべてページ 3 に置いて
  あります。配置を変える場合はこの点に注意してください。
