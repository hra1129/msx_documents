#!/usr/bin/env python3
"""build_sample.py -- カーネル + 差し替えドライバの合成 ROM を作る。

既存の disk ROM（F1XDJ のものを想定）のカーネル部分はそのままに、
ドライバ領域 (7400H〜7FFFH) を romdisk.asm のバイナリで置き換え、
カーネル側の接続点をすべて新しいドライバへ向け直した ROM を出力する。

接続点は本書の解析で確定した 14 箇所である（アドレスは CPU 空間）:

  ジャンプテーブル   4011H/4014H/4017H/401AH/401DH/4020H の飛び先
  INIT 内の呼び出し  5770H (INIHRD) / 5851H (DRIVES) / 5890H (INIENV)
  STATEMENT の飛び先 65AFH (OEMSTA)
  DEFDPB の参照      5884H (LD HL,DEFDPB) と 5AE8H (LD A,(DEFDPB+1))
  MYSIZE の即値      57AAH (LD HL,F380H+MYSIZE) と 581EH (LD HL,MYSIZE)

入力 ROM の各接続点には、想定したカーネル（F1XDJ）の値が入っている
ことを確認してから書き換える。値が違う ROM を渡すと、書き換えずに
エラーで止まる（無言で壊れた ROM を作らないため）。

★注意: 出力される合成 ROM は、他者の著作物であるカーネル部分を
  含む。検証専用であり、再配布は厳禁。配布するのはドライバの
  ソースとこのツールまでで、合成は各自の手元の ROM で行うこと。

使い方:
  python3 build_sample.py --diskrom hb-f1xdj_disk.rom \
      --driver romdisk.bin --out romdisk_full.rom
"""

import argparse
import hashlib
import struct
import sys

MYSIZE = 16                 # romdisk.asm の MYSIZE と一致させること
DRIVER_BASE = 0x7400
DRIVER_OFF = DRIVER_BASE - 0x4000
DRIVER_SIZE = 0xC00         # 7400H〜7FFFH
DEFDPB_OFF = 0x1E           # ドライバ内での DEFDPB のオフセット

# ベクタテーブルの並び（romdisk.asm の vec_* と同じ順）
VECTORS = ['DSKIO', 'DSKCHG', 'GETDPB', 'CHOICE', 'DSKFMT', 'MTROFF',
           'INIHRD', 'DRIVES', 'INIENV', 'OEMSTA']

# パッチ表: (アドレス, 想定される元の operand 値, 書き込む値の名前)
# 値は 16 ビットリトルエンディアンで格納されている箇所だけを扱う。
PATCHES = [
    (0x4011, 0x751E, 'DSKIO'),     # JP DSKIO の飛び先
    (0x4014, 0x78BA, 'DSKCHG'),    # JP DSKCHG
    (0x4017, 0x7943, 'GETDPB'),    # JP GETDPB
    (0x401A, 0x795D, 'CHOICE'),    # JP CHOICE
    (0x401D, 0x79A0, 'DSKFMT'),    # JP DSKFMT
    (0x4020, 0x7DE2, 'MTROFF'),    # JP MTROFF
    (0x5770, 0x7827, 'INIHRD'),    # CALL INIHRD の飛び先
    (0x5851, 0x7867, 'DRIVES'),    # CALL DRIVES
    (0x5890, 0x78A7, 'INIENV'),    # CALL INIENV
    (0x65AF, 0x7DE0, 'OEMSTA'),    # JP OEMSTA
    (0x5884, 0x74E7, 'DEFDPB'),    # LD HL,DEFDPB
    (0x5AE8, 0x74E8, 'DEFDPB+1'),  # LD A,(DEFDPB+1) ブート時のメディア ID
    (0x57AA, 0xF389, 'F380+MYSIZE'),
    (0x581E, 0x0009, 'MYSIZE'),
]


def fail(msg):
    print(f'エラー: {msg}', file=sys.stderr)
    sys.exit(1)


def main():
    ap = argparse.ArgumentParser(description='合成 ROM を作る（検証専用）')
    ap.add_argument('--diskrom', required=True, help='元の disk ROM (16KB)')
    ap.add_argument('--driver', required=True, help='romdisk.bin (zma の出力)')
    ap.add_argument('--out', required=True, help='出力する合成 ROM')
    args = ap.parse_args()

    with open(args.diskrom, 'rb') as fh:
        rom = bytearray(fh.read())
    with open(args.driver, 'rb') as fh:
        drv = fh.read()

    if len(rom) != 0x4000 or rom[0:2] != b'AB':
        fail('disk ROM は "AB" ヘッダを持つ 16KB のイメージではありません')
    if len(drv) > DRIVER_SIZE:
        fail(f'ドライバが領域 ({DRIVER_SIZE} バイト) に収まりません: {len(drv)} バイト')
    if len(drv) < DEFDPB_OFF + 21:
        fail('ドライバが短すぎます (DEFDPB が含まれていません)')

    # ドライバ先頭のベクタテーブルを読む (JP xxxx が 10 本)
    entries = {}
    for i, name in enumerate(VECTORS):
        off = i * 3
        if drv[off] != 0xC3:
            fail(f'ベクタテーブル {name} の位置に JP 命令がありません')
        entries[name] = struct.unpack_from('<H', drv, off + 1)[0]
        if not (DRIVER_BASE <= entries[name] < 0x8000):
            fail(f'ベクタ {name} の飛び先がドライバ領域外です: {entries[name]:04X}H')
    # DEFDPB の置き場所と中身の sanity check
    if drv[DEFDPB_OFF] != 0 or drv[DEFDPB_OFF + 1] != 0xF9:
        fail('ドライバの DEFDPB (オフセット 1EH) が想定と違います')
    entries['DEFDPB'] = DRIVER_BASE + DEFDPB_OFF
    entries['DEFDPB+1'] = DRIVER_BASE + DEFDPB_OFF + 1
    entries['F380+MYSIZE'] = 0xF380 + MYSIZE
    entries['MYSIZE'] = MYSIZE

    # 接続点を確認してから書き換える
    for addr, expected, key in PATCHES:
        off = addr - 0x4000
        cur = struct.unpack_from('<H', rom, off)[0]
        if cur != expected:
            fail(f'接続点 {addr:04X}H の値が想定と違います '
                 f'(現在 {cur:04X}H, 想定 {expected:04X}H)。'
                 '想定したカーネル (F1XDJ) の ROM ではありません')
        struct.pack_into('<H', rom, off, entries[key])

    # ドライバ領域を置き換える（余りは FFH で埋める）
    rom[DRIVER_OFF:DRIVER_OFF + DRIVER_SIZE] = b'\xFF' * DRIVER_SIZE
    rom[DRIVER_OFF:DRIVER_OFF + len(drv)] = drv

    with open(args.out, 'wb') as fh:
        fh.write(rom)
    sha1 = hashlib.sha1(rom).hexdigest()
    print(f'{args.out}: {len(rom)} バイト, sha1 {sha1}')
    print(f'ドライバ: {len(drv)} バイト (領域 {DRIVER_SIZE} バイト中)')
    print('接続点 14 箇所を書き換えました:')
    for name in VECTORS:
        print(f'  {name:7s} -> {entries[name]:04X}H')
    print(f'  DEFDPB  -> {entries["DEFDPB"]:04X}H, MYSIZE = {MYSIZE}')
    print('★この合成 ROM はカーネル部分の著作権のため再配布禁止です（検証専用）')


if __name__ == '__main__':
    main()
