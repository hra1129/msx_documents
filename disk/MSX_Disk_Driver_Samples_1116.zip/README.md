# ROM ディスクサンプル

「MSX-DOS／MSX-DOS2 ディスクドライバドキュメント」第 7 章の実働サンプルです。
既存の DiskBIOS カーネル（Sony HB-F1XDJ の disk ROM）のドライバ領域を
読み取り専用の自作ドライバに差し替え、もう一方のカートリッジスロットに
入れたデータ ROM を Disk BASIC のドライブ A: として使えるようにします。

## ファイル

|ファイル|内容|
|-|-|
|romdisk.asm|ドライバ本体（Z80 アセンブラ、zma 記法）。7400H 配置、481 バイト|
|build_sample.py|手元の disk ROM とドライバを合成するツール（接続点の書き換え）|
|make_romdisk.py|データ ROM（署名＋FAT12 イメージ）の生成ツール|
|demo.bas|データ ROM に収録するデモ用 BASIC プログラム|

## ビルド手順

```
# 1. ドライバをアセンブル（zma はソースのあるディレクトリで実行）
zma romdisk.asm romdisk.bin

# 2. データ ROM を作る（入れたいファイルを引数に並べる）
python3 make_romdisk.py -o romdisk_data.rom demo.bas

# 3. 手元の disk ROM と合成する
python3 build_sample.py --diskrom <F1XDJ の disk ROM> \
    --driver romdisk.bin --out romdisk_full.rom
```

build_sample.py は、接続点の元の値が想定したカーネル（F1XDJ）のものと
一致することを確認してから書き換えます。想定外の ROM には合成を中止します。

## 実行

合成 ROM（romdisk_full.rom）をディスクインターフェースの ROM として使い、
データ ROM（romdisk_data.rom）をカートリッジスロットに入れて起動すると、
Disk BASIC で A: が ROM ディスクになります。

- `FILES "A:"` で収録ファイルが見えます
- `LOAD "A:DEMO.BAS"` → `RUN` でデモが動きます
- `SAVE "A:..."` は "Disk write protected" になります（読み取り専用）
- ドライブは A: のみです（B: は "Bad drive name"）

エミュレーター（openMSX）では、マシン定義のディスク ROM を合成 ROM に
差し替え（ファイル名と sha1 を変更）、データ ROM をカートリッジとして
挿入する形で再現できます。

## 注意（著作権）

合成 ROM には他者の著作物であるカーネル部分が含まれるため、
**合成 ROM は再配布しないでください**。このリポジトリで配布するのは
自作のドライバソースとツールのみです。合成は、各自が正当に所有する
disk ROM に対して行ってください。

## 仕様メモ

- データ ROM：16KB。4010H に署名 "ROMDISK"、4018H に総セクタ数、
  4020H から FAT12 イメージ（31 セクタ、512 バイト／セクタ）
- ドライバのワークエリア（MYSIZE）：16 バイト
- 対応メディア：F9H のみ（読み取り専用）
- ドライバの詳細な解説はドキュメント第 7 章を参照してください
