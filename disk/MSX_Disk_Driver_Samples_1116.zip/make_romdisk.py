#!/usr/bin/env python3
"""make_romdisk.py -- romdisk.asm 用のデータ ROM イメージ生成ツール。

16KB のカートリッジ ROM イメージを作る。中身は次の 2 つだけである。

  4000H〜 ヘッダと署名（"AB"、4010H に "ROMDISK"、4018H に総セクタ数）
  4020H〜 FAT12 イメージ（ブートセクタ + FAT x2 + ルート + データ）

ドライバ (romdisk.asm) は署名でこの ROM を探し、DSKIO の読みを
RDSLT でこのイメージから賄う。イメージのジオメトリはドライバ側の
メディアテーブル（DEFDPB）と一致させてある:

  セクタ長 512、1 クラスタ = 1 セクタ、総 31 セクタ
  セクタ 0 = ブート、1〜2 = FAT、3 = ルート (16 件)、4〜30 = データ

使い方:
  python3 make_romdisk.py -o romdisk_data.rom demo.bas [file2 ...]

  投入したファイルは、そのままの名前（8.3 形式に変換）で
  ルートディレクトリに登録される。容量はデータ領域 27 セクタ
  （= 27 クラスタ）まで。
"""

import argparse
import os
import struct
import sys

SECTOR = 512
TOTAL_SECTORS = 31
FAT_START = 1
NFATS = 2
FAT_SECTORS = 1
ROOT_START = 3
ROOT_ENTRIES = 16
DATA_START = 4
MAX_CLUSTER = 28            # クラスタ番号は 2 〜 28（27 クラスタ）
MEDIA = 0xF9
IMG_BASE = 0x4020           # ROM 内のイメージ先頭アドレス
ROM_SIZE = 0x4000

# DOS の日付/時刻形式にエンコードした固定値 (2026-11-16 12:00:00)。
# 生成物が毎回同じバイト列になるよう、現在時刻は使わない。
DOS_TIME = (12 << 11) | (0 << 5) | (0 // 2)
DOS_DATE = ((2026 - 1980) << 9) | (11 << 5) | 16


def name83(path):
    """ファイル名を 8.3 形式 (名前 8 文字 + 拡張子 3 文字) にする。"""
    base = os.path.basename(path).upper()
    if '.' in base:
        name, ext = base.rsplit('.', 1)
    else:
        name, ext = base, ''
    if not name or len(name) > 8 or len(ext) > 3:
        raise SystemExit(f'8.3 形式にできないファイル名です: {base}')
    for ch in name + ext:
        if not (ch.isalnum() or ch in "$%'-_@~`!(){}^#&"):
            raise SystemExit(f'ファイル名に使えない文字があります: {base}')
    return name.ljust(8).encode('ascii') + ext.ljust(3).encode('ascii')


def build_image(files):
    """files: [(name83_bytes, data_bytes), ...] -> FAT12 イメージ bytes"""
    img = bytearray(TOTAL_SECTORS * SECTOR)

    # --- ブートセクタ (セクタ 0) ---
    # 先頭バイトを EBH/E9H に「しない」ことで、DOS のブートコードとして
    # 起動されず、電源投入時は Disk BASIC に落ちるデータディスクにする
    # （カーネルは先頭バイトが EBH/E9H のときだけブートコードへ制御を
    # 移す。本書 3.7 節）。BPB はジオメトリと一致させて書いておく
    # （DOS2 が BPB から DPB を組み立てる場合の備え）。
    bs = img
    bs[0] = 0x00
    bs[3:11] = b'ROMDISK '
    struct.pack_into('<H', bs, 11, SECTOR)          # セクタ長
    bs[13] = 1                                       # セクタ/クラスタ
    struct.pack_into('<H', bs, 14, 1)                # 予約セクタ
    bs[16] = NFATS                                   # FAT の数
    struct.pack_into('<H', bs, 17, ROOT_ENTRIES)     # ルートエントリ数
    struct.pack_into('<H', bs, 19, TOTAL_SECTORS)    # 総セクタ数
    bs[21] = MEDIA                                   # メディアバイト
    struct.pack_into('<H', bs, 22, FAT_SECTORS)      # FAT のセクタ数
    note = (b'ROM DISK data cartridge for the romdisk.asm sample '
            b'driver. Not a system disk.')
    bs[0x40:0x40 + len(note)] = note

    # --- ルートディレクトリとデータ領域、FAT のクラスタ鎖 ---
    fat = bytearray(FAT_SECTORS * SECTOR)
    fat[0] = MEDIA
    fat[1] = 0xFF
    fat[2] = 0xFF

    def fat_set(n, val):
        off = n + n // 2
        if n & 1:
            fat[off] = (fat[off] & 0x0F) | ((val << 4) & 0xF0)
            fat[off + 1] = (val >> 4) & 0xFF
        else:
            fat[off] = val & 0xFF
            fat[off + 1] = (fat[off + 1] & 0xF0) | ((val >> 8) & 0x0F)

    root = ROOT_START * SECTOR
    cluster = 2
    for i, (nm, data) in enumerate(files):
        nclusters = max(1, (len(data) + SECTOR - 1) // SECTOR)
        if cluster + nclusters - 1 > MAX_CLUSTER:
            raise SystemExit('ファイルがデータ領域 (27 セクタ) に収まりません')
        first = cluster
        for k in range(nclusters):
            nxt = cluster + 1 if k < nclusters - 1 else 0xFFF
            fat_set(cluster, nxt)
            dst = (DATA_START + (cluster - 2)) * SECTOR
            chunk = data[k * SECTOR:(k + 1) * SECTOR]
            img[dst:dst + len(chunk)] = chunk
            cluster += 1
        ent = root + i * 32
        img[ent:ent + 11] = nm
        img[ent + 11] = 0x20                        # 属性: アーカイブ
        struct.pack_into('<H', img, ent + 14, DOS_TIME)
        struct.pack_into('<H', img, ent + 16, DOS_DATE)
        struct.pack_into('<H', img, ent + 26, first)
        struct.pack_into('<I', img, ent + 28, len(data))

    # FAT を 2 面とも書く
    for f in range(NFATS):
        off = (FAT_START + f * FAT_SECTORS) * SECTOR
        img[off:off + len(fat)] = fat

    return bytes(img)


def build_rom(files):
    img = build_image(files)
    rom = bytearray(ROM_SIZE)
    # カートリッジヘッダ: "AB" のみ。INIT 等はすべて 0
    # （呼ばれる入口を持たない、データだけの ROM にする）
    rom[0:2] = b'AB'
    # 署名とメタデータ (romdisk.asm の SIG_ADDR / HDR_SECTORS と一致)
    rom[0x10:0x17] = b'ROMDISK'
    rom[0x17] = 1                                   # 形式バージョン
    struct.pack_into('<H', rom, 0x18, TOTAL_SECTORS)
    # イメージ本体
    rom[IMG_BASE - 0x4000:IMG_BASE - 0x4000 + len(img)] = img
    # 残りは FFH（未使用の ROM 領域）で埋める
    tail = IMG_BASE - 0x4000 + len(img)
    for i in range(tail, ROM_SIZE):
        rom[i] = 0xFF
    return bytes(rom)


def main():
    ap = argparse.ArgumentParser(description='ROM ディスク用データ ROM を生成する')
    ap.add_argument('-o', '--out', default='romdisk_data.rom',
                    help='出力 ROM ファイル (既定: romdisk_data.rom)')
    ap.add_argument('files', nargs='+', help='イメージに入れるファイル')
    args = ap.parse_args()

    files = []
    for path in args.files:
        with open(path, 'rb') as fh:
            files.append((name83(path), fh.read()))
    rom = build_rom(files)
    with open(args.out, 'wb') as fh:
        fh.write(rom)
    names = ', '.join(n.decode('ascii').strip() for n, _ in files)
    print(f'{args.out}: {len(rom)} バイト, 収録ファイル: {names}')


if __name__ == '__main__':
    main()
