; FCBRAND - FCB random block access (record size = 16 bytes)
;
; Creates RAND.BIN with 4 records of 16 bytes ("REC0:" + dots,
; "REC1:" + dots, ...), reads back record 2 with _RDBLK, and
; writes the result to RESULT.TXT (16 bytes).
;
; Points demonstrated:
;   - The record size field (FCB+14) is used ONLY by the block
;     functions _WRBLK/_RDBLK. It must be set by the program
;     AFTER open/create, before the first block call.
;   - The random record number lives at FCB+33..36 and is
;     advanced automatically by the block functions.
;   - _RDBLK returns the number of records actually read in HL.
;
; Common to MSX-DOS and MSX-DOS2.

        org     0x100

BDOS    equ     0x0005

_FMAKE  equ     0x16
_FCLOSE equ     0x10
_SETDTA equ     0x1A
_WRBLK  equ     0x26
_RDBLK  equ     0x27
_CONOUT equ     0x02
_TERM0  equ     0x00

start:
        ; --- FCB for RAND.BIN: zero everything, then the name.
        ;     (Record size is NOT set yet: it belongs after FMAKE.)
        ld      hl, fcb1
        ld      de, fcb1 + 1
        ld      bc, 36
        ld      [hl], 0
        ldir
        ld      hl, name1
        ld      de, fcb1 + 1
        ld      bc, 11
        ldir

        ld      c, _FMAKE
        ld      de, fcb1
        call    BDOS
        or      a
        jp      nz, error

        ; --- Now set the record size (16) at FCB+14.
        ld      hl, 16
        ld      [fcb1 + 14], hl

        ld      c, _SETDTA
        ld      de, recbuf
        call    BDOS

        ; --- Write records 0..3.
        xor     a
        ld      [recno], a
wloop:
        ; pattern: "RECn:" + 11 dots (digit is at offset 3)
        ld      a, [recno]
        add     a, '0'
        ld      [recbuf + 3], a
        ; random record number at FCB+33 (4 bytes)
        ld      a, [recno]
        ld      [fcb1 + 33], a
        xor     a
        ld      [fcb1 + 34], a
        ld      [fcb1 + 35], a
        ld      [fcb1 + 36], a
        ld      c, _WRBLK
        ld      de, fcb1
        ld      hl, 1                   ; 1 record
        call    BDOS
        or      a
        jp      nz, error
        ld      a, [recno]
        inc     a
        ld      [recno], a
        cp      4
        jr      c, wloop

        ; --- Read back record 2 (block calls advanced the
        ;     random record number, so set it again).
        ld      a, 2
        ld      [fcb1 + 33], a
        ld      c, _RDBLK
        ld      de, fcb1
        ld      hl, 1
        call    BDOS
        or      a
        jp      nz, error
        ld      a, h                    ; HL = records read
        or      l
        jp      z, error
        dec     hl
        ld      a, h
        or      l
        jp      nz, error               ; must be exactly 1

        ld      c, _FCLOSE
        ld      de, fcb1
        call    BDOS

        ; --- RESULT.TXT via a second FCB (same procedure).
        ld      hl, fcb2
        ld      de, fcb2 + 1
        ld      bc, 36
        ld      [hl], 0
        ldir
        ld      hl, name2
        ld      de, fcb2 + 1
        ld      bc, 11
        ldir
        ld      c, _FMAKE
        ld      de, fcb2
        call    BDOS
        or      a
        jp      nz, error
        ld      hl, 16
        ld      [fcb2 + 14], hl
        xor     a
        ld      [fcb2 + 33], a
        ld      [fcb2 + 34], a
        ld      [fcb2 + 35], a
        ld      [fcb2 + 36], a
        ld      c, _SETDTA
        ld      de, recbuf
        call    BDOS
        ld      c, _WRBLK
        ld      de, fcb2
        ld      hl, 1
        call    BDOS
        or      a
        jp      nz, error
        ld      c, _FCLOSE
        ld      de, fcb2
        call    BDOS

        ld      hl, msg_ok
        jp      puts

error:
        ld      hl, msg_err
puts:
        ld      a, [hl]
        or      a
        jr      z, done
        push    hl
        ld      e, a
        ld      c, _CONOUT
        call    BDOS
        pop     hl
        inc     hl
        jr      puts
done:
        ld      c, _TERM0
        jp      BDOS

name1:  db      "RAND    BIN"           ; name "RAND    " + ext "BIN"
name2:  db      "RESULT  TXT"           ; name "RESULT  " + ext "TXT"
recno:  db      0
recbuf: db      "REC0:..........."
msg_ok: db      "FCBRAND: RAND.BIN written, record 2 read back.", 0x0D, 0x0A, 0
msg_err: db     "FCBRAND: error.", 0x0D, 0x0A, 0

fcb1:   ds      40
fcb2:   ds      40
